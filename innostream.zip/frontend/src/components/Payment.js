import React, { useState } from 'react';
import { processPayment } from '../services/paymentService';
import { useNotification } from '../hooks/useNotification';

const Payment = () => {
    const [amount, setAmount] = useState('');
    const notify = useNotification();

    const handlePayment = async () => {
        const result = await processPayment(amount);
        if (result.success) {
            notify('Payment processed successfully!');
        } else {
            notify('Payment failed. Please try again.');
        }
    };

    return (
        <div>
            <h1>Payment</h1>
            <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Enter amount"
            />
            <button onClick={handlePayment}>Pay</button>
        </div>
    );
};

export default Payment;