import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import VideoPlayer from './VideoPlayer'; // Assurez-vous d'avoir un composant de lecteur vidéo
import { startLiveStream, endLiveStream, getLiveStreamData } from '../services/liveStreamService';
import { useNotification } from '../hooks/useNotification';

const LiveStream = () => {
    const { streamId } = useParams();
    const [streamData, setStreamData] = useState(null);
    const [isLive, setIsLive] = useState(false);
    const notify = useNotification();

    useEffect(() => {
        const fetchLiveStream = async () => {
            const data = await getLiveStreamData(streamId);
            if (data) {
                setStreamData(data);
                setIsLive(data.isLive);
            }
        };

        fetchLiveStream();
    }, [streamId]);

    const handleStart = async () => {
        const result = await startLiveStream(streamId);
        if (result.success) {
            notify('Live stream started successfully!');
            setIsLive(true);
        } else {
            notify('Failed to start live stream.');
        }
    };

    const handleEnd = async () => {
        const result = await endLiveStream(streamId);
        if (result.success) {
            notify('Live stream ended successfully!');
            setIsLive(false);
        } else {
            notify('Failed to end live stream.');
        }
    };

    return (
        <div>
            {streamData && (
                <>
                    <h1>{streamData.title}</h1>
                    <VideoPlayer src={streamData.videoUrl} />
                    <div>
                        {isLive ? (
                            <button onClick={handleEnd}>End Live Stream</button>
                        ) : (
                            <button onClick={handleStart}>Start Live Stream</button>
                        )}
                    </div>
                </>
            )}
        </div>
    );
};

export default LiveStream;