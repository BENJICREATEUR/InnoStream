import React, { useEffect, useState } from 'react';
import { getProducts } from '../services/marketplaceService';
import ProductCard from './ProductCard'; // Composant pour afficher chaque produit

const Marketplace = () => {
    const [products, setProducts] = useState([]);

    useEffect(() => {
        const fetchProducts = async () => {
            const data = await getProducts();
            setProducts(data);
        };

        fetchProducts();
    }, []);

    return (
        <div>
            <h1>Marketplace</h1>
            <div className="product-list">
                {products.map((product) => (
                    <ProductCard key={product.id} product={product} />
                ))}
            </div>
        </div>
    );
};

export default Marketplace;