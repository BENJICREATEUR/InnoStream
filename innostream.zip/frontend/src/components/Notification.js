import React, { useEffect, useState } from 'react';
import { getNotifications } from '../services/notificationService';
import { useNotification } from '../hooks/useNotification';

const Notification = () => {
    const [notifications, setNotifications] = useState([]);
    const notify = useNotification();

    useEffect(() => {
        const fetchNotifications = async () => {
            const data = await getNotifications();
            setNotifications(data);
        };

        fetchNotifications();
    }, []);

    const handleRead = (id) => {
        // Ici vous pouvez ajouter la logique pour marquer une notification comme lue
        notify(`Notification ${id} marked as read.`);
    };

    return (
        <div>
            <h1>Notifications</h1>
            <ul>
                {notifications.map((notification) => (
                    <li key={notification.id} onClick={() => handleRead(notification.id)}>
                        {notification.message}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Notification;