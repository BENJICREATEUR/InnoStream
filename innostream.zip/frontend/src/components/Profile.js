import React, { useEffect, useState } from 'react';
import { getUserProfile, updateUserProfile } from '../services/userService';
import { useNotification } from '../hooks/useNotification';

const Profile = () => {
    const [user, setUser] = useState({});
    const [isEditing, setIsEditing] = useState(false);
    const notify = useNotification();

    useEffect(() => {
        const fetchUserProfile = async () => {
            const data = await getUserProfile();
            setUser(data);
        };

        fetchUserProfile();
    }, []);

    const handleEditToggle = () => {
        setIsEditing(!isEditing);
    };

    const handleChange = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const result = await updateUserProfile(user);
        if (result.success) {
            notify('Profile updated successfully!');
            setIsEditing(false);
        } else {
            notify('Failed to update profile. Please try again.');
        }
    };

    return (
        <div>
            <h1>User Profile</h1>
            {isEditing ? (
                <form onSubmit={handleSubmit}>
                    <input
                        type="text"
                        name="name"
                        value={user.name || ''}
                        onChange={handleChange}
                        placeholder="Name"
                        required
                    />
                    <input
                        type="email"
                        name="email"
                        value={user.email || ''}
                        onChange={handleChange}
                        placeholder="Email"
                        required
                    />
                    <textarea
                        name="bio"
                        value={user.bio || ''}
                        onChange={handleChange}
                        placeholder="Biography"
                    />
                    <button type="submit">Save</button>
                    <button type="button" onClick={handleEditToggle}>Cancel</button>
                </form>
            ) : (
                <>
                    <p><strong>Name:</strong> {user.name}</p>
                    <p><strong>Email:</strong> {user.email}</p>
                    <p><strong>Bio:</strong> {user.bio}</p>
                    <button onClick={handleEditToggle}>Edit Profile</button>
                </>
            )}
        </div>
    );
};

export default Profile;