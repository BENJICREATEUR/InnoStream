import React, { useEffect, useState } from 'react';
import { getTestimonials, submitTestimonial } from '../services/testimonialService';
import { useNotification } from '../hooks/useNotification';

const Testimonial = () => {
    const [testimonials, setTestimonials] = useState([]);
    const [newTestimonial, setNewTestimonial] = useState('');
    const notify = useNotification();

    useEffect(() => {
        const fetchTestimonials = async () => {
            const data = await getTestimonials();
            setTestimonials(data);
        };

        fetchTestimonials();
    }, []);

    const handleChange = (e) => {
        setNewTestimonial(e.target.value);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const result = await submitTestimonial(newTestimonial);
        if (result.success) {
            notify('Testimonial submitted successfully!');
            setNewTestimonial('');
            const updatedTestimonials = await getTestimonials();
            setTestimonials(updatedTestimonials);
        } else {
            notify('Failed to submit testimonial. Please try again.');
        }
    };

    return (
        <div>
            <h1>Testimonials</h1>
            <form onSubmit={handleSubmit}>
                <textarea
                    value={newTestimonial}
                    onChange={handleChange}
                    placeholder="Write your testimonial"
                    required
                />
                <button type="submit">Submit Testimonial</button>
            </form>
            <ul>
                {testimonials.map((testimonial) => (
                    <li key={testimonial.id}>{testimonial.message}</li>
                ))}
            </ul>
        </div>
    );
};

export default Testimonial;