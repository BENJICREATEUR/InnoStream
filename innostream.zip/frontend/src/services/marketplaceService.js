import axios from 'axios';

const API_URL = '/api/marketplace';

// Récupérer la liste des produits disponibles
export const getMarketplaceProducts = async () => {
    try {
        const response = await axios.get(`${API_URL}/products`);
        return response.data;
    } catch (error) {
        return { success: false, message: 'Failed to fetch marketplace products' };
    }
};

// Ajouter un produit au marketplace
export const addProduct = async (productData) => {
    try {
        const response = await axios.post(`${API_URL}/product`, productData);
        return response.data;
    } catch (error) {
        return { success: false, message: error.response?.data?.message || 'Failed to add product' };
    }
};

// Acheter un produit dans le marketplace
export const purchaseProduct = async (productId) => {
    try {
        const response = await axios.post(`${API_URL}/purchase`, { productId });
        return response.data;
    } catch (error) {
        return { success: false, message: error.response?.data?.message || 'Failed to purchase product' };
    }
};

// Récupérer les transactions de l'utilisateur
export const getUserTransactions = async () => {
    try {
        const response = await axios.get(`${API_URL}/transactions`);
        return response.data;
    } catch (error) {
        return { success: false, message: 'Failed to fetch transactions' };
    }
};