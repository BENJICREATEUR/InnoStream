import axios from 'axios';

const API_URL = '/api/notifications';

// Récupérer les notifications d'un utilisateur
export const getUserNotifications = async () => {
    try {
        const response = await axios.get(`${API_URL}/user`);
        return response.data;
    } catch (error) {
        return { success: false, message: 'Failed to fetch notifications' };
    }
};

// Marquer une notification comme lue
export const markNotificationAsRead = async (notificationId) => {
    try {
        const response = await axios.post(`${API_URL}/read`, { notificationId });
        return response.data;
    } catch (error) {
        return { success: false, message: error.response?.data?.message || 'Failed to mark notification as read' };
    }
};

// Supprimer une notification
export const deleteNotification = async (notificationId) => {
    try {
        const response = await axios.delete(`${API_URL}/delete`, { data: { notificationId } });
        return response.data;
    } catch (error) {
        return { success: false, message: error.response?.data?.message || 'Failed to delete notification' };
    }
};

// Envoyer une notification push
export const sendPushNotification = async (notificationData) => {
    try {
        const response = await axios.post(`${API_URL}/push`, notificationData);
        return response.data;
    } catch (error) {
        return { success: false, message: error.response?.data?.message || 'Failed to send push notification' };
    }
};