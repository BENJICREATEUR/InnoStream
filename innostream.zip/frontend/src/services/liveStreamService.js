import axios from 'axios';

const API_URL = '/api/livestream';

// Démarrer un live stream
export const startLiveStream = async (streamData) => {
    try {
        const response = await axios.post(`${API_URL}/start`, streamData);
        return response.data;
    } catch (error) {
        return { success: false, message: error.response?.data?.message || 'Failed to start live stream' };
    }
};

// Terminer un live stream
export const endLiveStream = async (streamId) => {
    try {
        const response = await axios.post(`${API_URL}/end`, { streamId });
        return response.data;
    } catch (error) {
        return { success: false, message: error.response?.data?.message || 'Failed to end live stream' };
    }
};

// Récupérer les live streams actifs
export const getActiveLiveStreams = async () => {
    try {
        const response = await axios.get(`${API_URL}/active`);
        return response.data;
    } catch (error) {
        return { success: false, message: 'Failed to fetch active live streams' };
    }
};

// Rejoindre un live stream
export const joinLiveStream = async (streamId) => {
    try {
        const response = await axios.post(`${API_URL}/join`, { streamId });
        return response.data;
    } catch (error) {
        return { success: false, message: error.response?.data?.message || 'Failed to join live stream' };
    }
};

// Envoyer un message pendant le live
export const sendMessageInLive = async (streamId, message) => {
    try {
        const response = await axios.post(`${API_URL}/message`, { streamId, message });
        return response.data;
    } catch (error) {
        return { success: false, message: error.response?.data?.message || 'Failed to send message' };
    }
};