import axios from 'axios';

const API_URL = '/api/video';

// Télécharger une vidéo
export const uploadVideo = async (formData) => {
    try {
        const response = await axios.post(`${API_URL}/upload`, formData, {
            headers: { 'Content-Type': 'multipart/form-data' },
        });
        return response.data;
    } catch (error) {
        return { success: false, message: 'Video upload failed' };
    }
};

// Récupérer les vidéos d'un utilisateur
export const getUserVideos = async () => {
    try {
        const response = await axios.get(`${API_URL}/user`);
        return response.data;
    } catch (error) {
        return { success: false, message: 'Failed to fetch user videos' };
    }
};

// Supprimer une vidéo
export const deleteVideo = async (videoId) => {
    try {
        const response = await axios.post(`${API_URL}/delete`, { videoId });
        return response.data;
    } catch (error) {
        return { success: false, message: 'Failed to delete video' };
    }
};

// Récupérer les vidéos populaires
export const getPopularVideos = async () => {
    try {
        const response = await axios.get(`${API_URL}/popular`);
        return response.data;
    } catch (error) {
        return { success: false, message: 'Failed to fetch popular videos' };
    }
};

// Récupérer les vidéos sponsorisées
export const getSponsoredVideos = async () => {
    try {
        const response = await axios.get(`${API_URL}/sponsored`);
        return response.data;
    } catch (error) {
        return { success: false, message: 'Failed to fetch sponsored videos' };
    }
};

// Commenter sur une vidéo
export const commentOnVideo = async (videoId, commentData) => {
    try {
        const response = await axios.post(`${API_URL}/comment`, { videoId, commentData });
        return response.data;
    } catch (error) {
        return { success: false, message: 'Failed to post comment' };
    }
};

// Récupérer les commentaires d'une vidéo
export const getVideoComments = async (videoId) => {
    try {
        const response = await axios.get(`${API_URL}/comments`, { params: { videoId } });
        return response.data;
    } catch (error) {
        return { success: false, message: 'Failed to fetch video comments' };
    }
};