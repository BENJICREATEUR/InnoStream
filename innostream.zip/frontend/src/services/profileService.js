import axios from 'axios';

const API_URL = '/api/profile';

// Récupérer les informations du profil utilisateur
export const getUserProfile = async () => {
    try {
        const response = await axios.get(`${API_URL}/user`);
        return response.data;
    } catch (error) {
        return { success: false, message: 'Failed to fetch user profile' };
    }
};

// Mettre à jour le profil utilisateur
export const updateUserProfile = async (profileData) => {
    try {
        const response = await axios.post(`${API_URL}/update`, profileData);
        return response.data;
    } catch (error) {
        return { success: false, message: error.response?.data?.message || 'Profile update failed' };
    }
};

// Télécharger une photo de profil
export const uploadProfilePicture = async (formData) => {
    try {
        const response = await axios.post(`${API_URL}/upload-picture`, formData, {
            headers: { 'Content-Type': 'multipart/form-data' },
        });
        return response.data;
    } catch (error) {
        return { success: false, message: 'Failed to upload profile picture' };
    }
};

// Gérer les abonnements de l'utilisateur
export const getUserFollowers = async () => {
    try {
        const response = await axios.get(`${API_URL}/followers`);
        return response.data;
    } catch (error) {
        return { success: false, message: 'Failed to fetch followers' };
    }
};

// Ajouter ou supprimer un abonnement
export const followOrUnfollowUser = async (userId) => {
    try {
        const response = await axios.post(`${API_URL}/follow-unfollow`, { userId });
        return response.data;
    } catch (error) {
        return { success: false, message: error.response?.data?.message || 'Failed to follow/unfollow user' };
    }
};