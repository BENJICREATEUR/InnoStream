import axios from 'axios';

const API_URL = '/api/payment';

// Initier un paiement
export const initiatePayment = async (paymentData) => {
    try {
        const response = await axios.post(`${API_URL}/initiate`, paymentData);
        return response.data;
    } catch (error) {
        return { success: false, message: error.response?.data?.message || 'Payment initiation failed' };
    }
};

// Récupérer l'historique des paiements de l'utilisateur
export const getPaymentHistory = async () => {
    try {
        const response = await axios.get(`${API_URL}/history`);
        return response.data;
    } catch (error) {
        return { success: false, message: 'Failed to fetch payment history' };
    }
};

// Gérer le paiement d'un abonnement
export const subscribe = async (subscriptionData) => {
    try {
        const response = await axios.post(`${API_URL}/subscribe`, subscriptionData);
        return response.data;
    } catch (error) {
        return { success: false, message: error.response?.data?.message || 'Subscription failed' };
    }
};

// Annuler un abonnement
export const cancelSubscription = async () => {
    try {
        const response = await axios.post(`${API_URL}/cancel-subscription`);
        return response.data;
    } catch (error) {
        return { success: false, message: 'Failed to cancel subscription' };
    }
};

// Vérifier le statut d'un paiement
export const verifyPayment = async (paymentId) => {
    try {
        const response = await axios.post(`${API_URL}/verify`, { paymentId });
        return response.data;
    } catch (error) {
        return { success: false, message: 'Payment verification failed' };
    }
};