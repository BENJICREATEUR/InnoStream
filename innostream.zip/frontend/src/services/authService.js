import axios from 'axios';

const API_URL = '/api/auth';

// Inscription d'un utilisateur
export const register = async (userData) => {
    try {
        const response = await axios.post(`${API_URL}/register`, userData);
        return response.data;
    } catch (error) {
        return { success: false, message: error.response?.data?.message || 'Registration failed' };
    }
};

// Connexion d'un utilisateur
export const login = async (credentials) => {
    try {
        const response = await axios.post(`${API_URL}/login`, credentials);
        return response.data;
    } catch (error) {
        return { success: false, message: error.response?.data?.message || 'Login failed' };
    }
};

// Déconnexion d'un utilisateur
export const logout = async () => {
    try {
        const response = await axios.post(`${API_URL}/logout`);
        return response.data;
    } catch (error) {
        return { success: false, message: 'Logout failed' };
    }
};

// Vérification de l'authentification par token
export const verifyToken = async (token) => {
    try {
        const response = await axios.post(`${API_URL}/verify-token`, { token });
        return response.data;
    } catch (error) {
        return { success: false, message: 'Token verification failed' };
    }
};

// Récupération du profil de l'utilisateur authentifié
export const getUserProfile = async () => {
    try {
        const response = await axios.get(`${API_URL}/profile`);
        return response.data;
    } catch (error) {
        return { success: false, message: 'Failed to fetch user profile' };
    }
};