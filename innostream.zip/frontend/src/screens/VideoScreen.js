import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getVideoDetails } from '../services/videoService';
import VideoPlayer from '../components/VideoPlayer';

const VideoScreen = () => {
    const { id } = useParams();
    const [video, setVideo] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchVideo = async () => {
            const data = await getVideoDetails(id);
            setVideo(data);
            setLoading(false);
        };

        fetchVideo();
    }, [id]);

    if (loading) return <div>Loading...</div>;

    return (
        <div>
            <h1>{video.title}</h1>
            <VideoPlayer src={video.videoUrl} />
            <p>{video.description}</p>
            <p>Posted by: {video.uploader}</p>
            <p>Views: {video.views}</p>
        </div>
    );
};

export default VideoScreen;