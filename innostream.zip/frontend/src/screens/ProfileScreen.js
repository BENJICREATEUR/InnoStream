import React, { useEffect, useState } from 'react';
import { getUserProfile, updateUserProfile } from '../services/userService';
import { useNotification } from '../hooks/useNotification';

const ProfileScreen = () => {
    const [profile, setProfile] = useState({});
    const [loading, setLoading] = useState(true);
    const notify = useNotification();

    useEffect(() => {
        const fetchProfile = async () => {
            const data = await getUserProfile();
            setProfile(data);
            setLoading(false);
        };

        fetchProfile();
    }, []);

    const handleChange = (e) => {
        setProfile({ ...profile, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await updateUserProfile(profile);
            if (response.success) {
                notify('Profile updated successfully!');
            } else {
                notify(response.message || 'Profile update failed. Please try again.');
            }
        } catch (error) {
            notify('An error occurred while updating the profile.');
        }
    };

    if (loading) return <div>Loading...</div>;

    return (
        <div>
            <h1>Profile</h1>
            <form onSubmit={handleSubmit}>
                <input
                    type="text"
                    name="username"
                    value={profile.username || ''}
                    onChange={handleChange}
                    placeholder="Username"
                    required
                />
                <input
                    type="email"
                    name="email"
                    value={profile.email || ''}
                    onChange={handleChange}
                    placeholder="Email"
                    required
                />
                <button type="submit">Update Profile</button>
            </form>
        </div>
    );
};

export default ProfileScreen;