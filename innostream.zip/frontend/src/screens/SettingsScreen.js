import React, { useState } from 'react';
import { updateSettings } from '../services/settingsService';
import { useNotification } from '../hooks/useNotification';

const SettingsScreen = () => {
    const [settings, setSettings] = useState({ notifications: true, darkMode: false });
    const notify = useNotification();

    const handleChange = (e) => {
        setSettings({ ...settings, [e.target.name]: e.target.checked });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await updateSettings(settings);
            if (response.success) {
                notify('Settings updated successfully!');
            } else {
                notify(response.message || 'Settings update failed. Please try again.');
            }
        } catch (error) {
            notify('An error occurred while updating settings.');
        }
    };

    return (
        <div>
            <h1>Settings</h1>
            <form onSubmit={handleSubmit}>
                <label>
                    <input
                        type="checkbox"
                        name="notifications"
                        checked={settings.notifications}
                        onChange={handleChange}
                    />
                    Enable Notifications
                </label>
                <label>
                    <input
                        type="checkbox"
                        name="darkMode"
                        checked={settings.darkMode}
                        onChange={handleChange}
                    />
                    Dark Mode
                </label>
                <button type="submit">Save Settings</button>
            </form>
        </div>
    );
};

export default SettingsScreen;