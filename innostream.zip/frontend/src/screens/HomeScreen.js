import React from 'react';
import { Link } from 'react-router-dom';
import LiveStreamList from '../components/LiveStreamList';
import VideoRecommendation from '../components/VideoRecommendation';

const HomeScreen = () => {
    return (
        <div>
            <h1>Welcome to InnoStream!</h1>
            <h2>Recommended Videos</h2>
            <VideoRecommendation />
            <h2>Live Streams</h2>
            <LiveStreamList />
            <Link to="/marketplace">Go to Marketplace</Link>
        </div>
    );
};

export default HomeScreen;