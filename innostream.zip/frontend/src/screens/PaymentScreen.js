import React, { useEffect, useState } from 'react';
import { getUserPaymentMethods, createPayment } from '../services/paymentService';
import { useNotification } from '../hooks/useNotification';

const PaymentScreen = () => {
    const [paymentMethods, setPaymentMethods] = useState([]);
    const [amount, setAmount] = useState('');
    const notify = useNotification();

    useEffect(() => {
        const fetchPaymentMethods = async () => {
            const methods = await getUserPaymentMethods();
            setPaymentMethods(methods);
        };

        fetchPaymentMethods();
    }, []);

    const handlePayment = async (e) => {
        e.preventDefault();
        try {
            const response = await createPayment({ amount });
            if (response.success) {
                notify('Payment successful!');
                setAmount('');
            } else {
                notify(response.message || 'Payment failed. Please try again.');
            }
        } catch (error) {
            notify('An error occurred during the payment process.');
        }
    };

    return (
        <div>
            <h1>Payment</h1>
            <h2>Your Payment Methods</h2>
            <ul>
                {paymentMethods.map((method) => (
                    <li key={method.id}>{method.details}</li>
                ))}
            </ul>
            <form onSubmit={handlePayment}>
                <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="Enter amount"
                    required
                />
                <button type="submit">Pay</button>
            </form>
        </div>
    );
};

export default PaymentScreen;