import React, { useEffect, useState } from 'react';
import { getNotifications } from '../services/notificationService';

const NotificationScreen = () => {
    const [notifications, setNotifications] = useState([]);

    useEffect(() => {
        const fetchNotifications = async () => {
            const data = await getNotifications();
            setNotifications(data);
        };

        fetchNotifications();
    }, []);

    return (
        <div>
            <h1>Notifications</h1>
            {notifications.length === 0 ? (
                <p>No notifications</p>
            ) : (
                <ul>
                    {notifications.map((notification) => (
                        <li key={notification.id}>{notification.message}</li>
                    ))}
                </ul>
            )}
        </div>
    );
};

export default NotificationScreen;