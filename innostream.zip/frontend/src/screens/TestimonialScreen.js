import React, { useEffect, useState } from 'react';
import { getTestimonials, submitTestimonial } from '../services/testimonialService';
import { useNotification } from '../hooks/useNotification';

const TestimonialScreen = () => {
    const [testimonials, setTestimonials] = useState([]);
    const [newTestimonial, setNewTestimonial] = useState('');
    const notify = useNotification();

    useEffect(() => {
        const fetchTestimonials = async () => {
            const data = await getTestimonials();
            setTestimonials(data);
        };

        fetchTestimonials();
    }, []);

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await submitTestimonial({ message: newTestimonial });
            if (response.success) {
                notify('Testimonial submitted successfully!');
                setNewTestimonial('');
                setTestimonials((prev) => [...prev, response.data]);
            } else {
                notify(response.message || 'Submission failed. Please try again.');
            }
        } catch (error) {
            notify('An error occurred while submitting the testimonial.');
        }
    };

    return (
        <div>
            <h1>Testimonials</h1>
            <form onSubmit={handleSubmit}>
                <textarea
                    value={newTestimonial}
                    onChange={(e) => setNewTestimonial(e.target.value)}
                    placeholder="Write your testimonial..."
                    required
                />
                <button type="submit">Submit Testimonial</button>
            </form>
            <h2>Previous Testimonials</h2>
            <ul>
                {testimonials.map((testimonial) => (
                    <li key={testimonial.id}>{testimonial.message}</li>
                ))}
            </ul>
        </div>
    );
};

export default TestimonialScreen;