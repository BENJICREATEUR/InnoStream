import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getLiveStreamById } from '../services/liveStreamService';
import VideoPlayer from '../components/VideoPlayer';

const LiveStreamScreen = () => {
    const { id } = useParams();
    const [liveStream, setLiveStream] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchLiveStream = async () => {
            const data = await getLiveStreamById(id);
            setLiveStream(data);
            setLoading(false);
        };

        fetchLiveStream();
    }, [id]);

    if (loading) return <div>Loading...</div>;

    return (
        <div>
            <h1>{liveStream.title}</h1>
            <VideoPlayer src={liveStream.videoUrl} />
            <p>{liveStream.description}</p>
        </div>
    );
};

export default LiveStreamScreen;