import React from 'react';
import MarketplaceItems from '../components/MarketplaceItems';

const MarketplaceScreen = () => {
    return (
        <div>
            <h1>Marketplace</h1>
            <MarketplaceItems />
        </div>
    );
};

export default MarketplaceScreen;