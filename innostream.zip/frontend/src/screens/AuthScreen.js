import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { loginUser, registerUser } from '../services/authService';
import { useNotification } from '../hooks/useNotification';

const AuthScreen = () => {
    const [isLogin, setIsLogin] = useState(true);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const notify = useNotification();
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (isLogin) {
                const response = await loginUser({ email, password });
                if (response.success) {
                    notify('Login successful!');
                    navigate('/home');
                } else {
                    notify(response.message || 'Login failed. Please try again.');
                }
            } else {
                const response = await registerUser({ email, password });
                if (response.success) {
                    notify('Registration successful! You can now log in.');
                    setIsLogin(true);
                } else {
                    notify(response.message || 'Registration failed. Please try again.');
                }
            }
        } catch (error) {
            notify('An error occurred. Please try again.');
        }
    };

    return (
        <div>
            <h1>{isLogin ? 'Login' : 'Register'}</h1>
            <form onSubmit={handleSubmit}>
                <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Email"
                    required
                />
                <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Password"
                    required
                />
                <button type="submit">{isLogin ? 'Login' : 'Register'}</button>
            </form>
            <button onClick={() => setIsLogin(!isLogin)}>
                {isLogin ? 'Need an account? Register' : 'Have an account? Login'}
            </button>
        </div>
    );
};

export default AuthScreen;