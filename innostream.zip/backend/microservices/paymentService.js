const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const User = require('../models/User');
const Video = require('../models/Video');

module.exports = {
  // Create a new subscription
  async createSubscription(userId, paymentMethodId) {
    try {
      const user = await User.findById(userId);

      // Create a customer if not already exists
      if (!user.stripeCustomerId) {
        const customer = await stripe.customers.create({
          email: user.email,
          payment_method: paymentMethodId,
        });
        user.stripeCustomerId = customer.id;
        await user.save();
      }

      // Create a subscription
      const subscription = await stripe.subscriptions.create({
        customer: user.stripeCustomerId,
        items: [{ price: process.env.SUBSCRIPTION_PRICE_ID }],
        payment_settings: {
          payment_method_types: ['card'],
          save_default_payment_method: 'on_subscription',
        },
        expand: ['latest_invoice.payment_intent'],
      });

      // Update user subscription status
      user.subscriptionId = subscription.id;
      user.isSubscribed = true;
      await user.save();

      return subscription;
    } catch (error) {
      throw new Error('Unable to create subscription: ' + error.message);
    }
  },

  // Handle successful subscription payment
  async handleSubscriptionPayment(req, res) {
    const { subscriptionId } = req.body;

    try {
      const subscription = await stripe.subscriptions.retrieve(subscriptionId);
      const user = await User.findOne({ stripeCustomerId: subscription.customer });

      // Check subscription status
      if (subscription.status === 'active') {
        user.isSubscribed = true;
        await user.save();
        return res.status(200).json({ message: 'Subscription activated', user });
      } else {
        return res.status(400).json({ message: 'Subscription payment failed' });
      }
    } catch (error) {
      return res.status(500).json({ message: 'Error processing subscription payment', error });
    }
  },

  // Handle payment for views
  async payForViews(videoId, viewCount) {
    try {
      const video = await Video.findById(videoId).populate('user');
      const creator = video.user;

      // Calculate payment
      const paymentAmount = viewCount * process.env.PAYMENT_PER_VIEW; // Amount in cents

      // Create a transfer to the creator
      await stripe.transfers.create({
        amount: paymentAmount,
        currency: 'usd',
        destination: creator.stripeAccountId, // Must be set up for creators
        description: `Payment for ${viewCount} views on video ${video.title}`,
      });

      return { message: 'Payment processed successfully', amount: paymentAmount };
    } catch (error) {
      throw new Error('Unable to process payment for views: ' + error.message);
    }
  },

  // Handle user payments
  async handlePayment(req, res) {
    const { amount, paymentMethodId } = req.body;

    try {
      const paymentIntent = await stripe.paymentIntents.create({
        amount, // Amount in cents
        currency: 'usd',
        payment_method: paymentMethodId,
        confirmation_method: 'manual',
        confirm: true,
      });

      return res.status(200).json({
        message: 'Payment successful',
        paymentIntent,
      });
    } catch (error) {
      return res.status(500).json({ message: 'Payment failed', error });
    }
  },

  // Retrieve payment methods
  async getPaymentMethods(userId) {
    try {
      const user = await User.findById(userId);
      if (!user.stripeCustomerId) {
        throw new Error('Customer does not exist.');
      }

      const paymentMethods = await stripe.paymentMethods.list({
        customer: user.stripeCustomerId,
        type: 'card',
      });

      return paymentMethods;
    } catch (error) {
      throw new Error('Unable to retrieve payment methods: ' + error.message);
    }
  },

  // Update user payment method
  async updatePaymentMethod(userId, newPaymentMethodId) {
    try {
      const user = await User.findById(userId);
      if (!user.stripeCustomerId) {
        throw new Error('Customer does not exist.');
      }

      // Attach new payment method to customer
      await stripe.paymentMethods.attach(newPaymentMethodId, {
        customer: user.stripeCustomerId,
      });

      // Set it as default
      await stripe.customers.update(user.stripeCustomerId, {
        invoice_settings: {
          default_payment_method: newPaymentMethodId,
        },
      });

      return { message: 'Payment method updated successfully' };
    } catch (error) {
      throw new Error('Unable to update payment method: ' + error.message);
    }
  },
};