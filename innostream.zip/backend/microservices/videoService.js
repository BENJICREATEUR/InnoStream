const Video = require('../models/Video');
const User = require('../models/User');
const { payForViews } = require('./paymentService'); // Importer le service de paiement

module.exports = {
  // Publier une nouvelle vidéo
  async publishVideo(userId, videoData) {
    try {
      const user = await User.findById(userId);
      if (!user) {
        throw new Error('User not found');
      }

      const newVideo = new Video({
        title: videoData.title,
        description: videoData.description,
        url: videoData.url,
        user: userId,
        views: 0,
        createdAt: new Date(),
      });

      const savedVideo = await newVideo.save();
      return savedVideo;
    } catch (error) {
      throw new Error('Error publishing video: ' + error.message);
    }
  },

  // Récupérer toutes les vidéos d'un utilisateur
  async getUserVideos(userId) {
    try {
      const videos = await Video.find({ user: userId }).sort({ createdAt: -1 });
      return videos;
    } catch (error) {
      throw new Error('Error retrieving user videos: ' + error.message);
    }
  },

  // Récupérer une vidéo par ID
  async getVideoById(videoId) {
    try {
      const video = await Video.findById(videoId).populate('user');
      if (!video) {
        throw new Error('Video not found');
      }
      return video;
    } catch (error) {
      throw new Error('Error retrieving video: ' + error.message);
    }
  },

  // Incrémenter le nombre de vues et payer le créateur
  async incrementViews(videoId) {
    try {
      const video = await Video.findById(videoId);
      if (!video) {
        throw new Error('Video not found');
      }

      // Incrémenter le nombre de vues
      video.views += 1;
      await video.save();

      // Payer le créateur pour la vue
      await payForViews(videoId, 1); // 1 vue

      return video;
    } catch (error) {
      throw new Error('Error incrementing views: ' + error.message);
    }
  },

  // Récupérer les vidéos les plus vues
  async getMostViewedVideos(limit = 10) {
    try {
      const videos = await Video.find()
        .sort({ views: -1 })
        .limit(limit)
        .populate('user');
      return videos;
    } catch (error) {
      throw new Error('Error retrieving most viewed videos: ' + error.message);
    }
  },

  // Récupérer les statistiques de performance d'une vidéo
  async getVideoStats(videoId) {
    try {
      const video = await Video.findById(videoId);
      if (!video) {
        throw new Error('Video not found');
      }

      return {
        title: video.title,
        views: video.views,
        createdAt: video.createdAt,
        user: video.user,
      };
    } catch (error) {
      throw new Error('Error retrieving video stats: ' + error.message);
    }
  },

  // Supprimer une vidéo
  async deleteVideo(videoId, userId) {
    try {
      const video = await Video.findById(videoId);
      if (!video) {
        throw new Error('Video not found');
      }

      // Vérifier si l'utilisateur est le créateur de la vidéo
      if (video.user.toString() !== userId) {
        throw new Error('Unauthorized: You can only delete your own videos');
      }

      await Video.findByIdAndRemove(videoId);
      return { message: 'Video deleted successfully' };
    } catch (error) {
      throw new Error('Error deleting video: ' + error.message);
    }
  },
};