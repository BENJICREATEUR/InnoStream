const Queue = require('bull');
const { sendNotificationEmail } = require('../utils/emailService');

const notificationQueue = new Queue('notificationQueue');

class QueueService {
    // Ajouter une tâche à la file d'attente pour l'envoi de notification
    static addNotificationToQueue(userId, title, message) {
        notificationQueue.add({ userId, title, message });
    }

    // Traitement des tâches dans la file d'attente
    static initQueue() {
        notificationQueue.process(async (job) => {
            const { userId, title, message } = job.data;
            try {
                await sendNotificationEmail(userId, title, message);
                console.log(`Notification sent to user ${userId}: ${title}`);
            } catch (error) {
                console.error('Error sending notification:', error);
            }
        });

        notificationQueue.on('completed', (job) => {
            console.log(`Job ${job.id} completed successfully.`);
        });

        notificationQueue.on('failed', (job, err) => {
            console.error(`Job ${job.id} failed: ${err.message}`);
        });
    }
}

module.exports = QueueService;