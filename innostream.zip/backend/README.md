# InnoStream Backend

InnoStream is a content creation and streaming platform that enables users to publish, share, and monetize their videos and live streams.

## Features

- **User Authentication**: Secure sign-up and login via email and social media (OAuth).
- **Live Streaming**: Users can start personal or sponsored live streams.
- **Marketplace**: Integrated marketplace for selling personal or sponsored products.
- **Video Optimization**: Automatic optimization of videos for better performance.
- **Real-time Messaging**: Instant messaging system for user interactions.
- **Notifications**: Real-time notifications for user activity and interactions.
- **Moderation Tools**: Tools for content moderation and security monitoring.

## Technologies Used

- **Node.js**: JavaScript runtime for building the server-side.
- **Express**: Web framework for building RESTful APIs.
- **MongoDB**: NoSQL database for storing user and content data.
- **Bull**: Job queue for handling background tasks.
- **FFmpeg**: Video processing and optimization.
- **JWT**: JSON Web Tokens for authentication.
- **Helmet**: Security middleware for setting HTTP headers.

## Getting Started

### Prerequisites

- Node.js (>=14.x)
- MongoDB (local or cloud)

### Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/innostream-backend.git
   cd innostream-backend