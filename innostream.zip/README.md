# InnoStream Backend

This repository contains the backend services for **InnoStream**, a video streaming and marketplace platform for content creators.

## Features

- **User Authentication**: Includes OAuth, email verification, and two-factor authentication (2FA).
- **Video Streaming**: Real-time video streaming using WebSockets and Socket.IO.
- **Marketplace**: Buy and sell products via the integrated marketplace with Stripe payment processing.
- **Notifications**: Real-time notifications using WebSockets.
- **User Profiles**: Profile management with support for avatars, followers, and preferences.
- **Security**: JWT-based authentication, encrypted passwords, and various security middlewares like Helmet and compression.
- **Cloud Storage**: Use of Cloudinary for media storage.

## Getting Started

### Prerequisites

Ensure you have the following installed:
- **Node.js** (>= 14.x)
- **MongoDB** (local or cloud-based)

### Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/innostream-backend.git
   cd innostream-backend